
package com.mycompany.financialforecasting;

public class FinancialForecasting {

    
    public double calculateFutureValue(double currentValue, double growthRate, int years) {
        double futureValue = currentValue;
        for (int i = 0; i < years; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }

    public static void main(String[] args) {
        FinancialForecasting forecasting = new FinancialForecasting();
        double currentValue = 1000; 
        double growthRate = 0.05; 
        int years = 10; 

        double futureValue = forecasting.calculateFutureValue(currentValue, growthRate, years);
        System.out.println("Future Value: " + futureValue);
    }
}


