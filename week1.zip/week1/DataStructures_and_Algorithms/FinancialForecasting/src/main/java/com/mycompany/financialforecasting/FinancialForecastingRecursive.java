
package com.mycompany.financialforecasting;

public class FinancialForecastingRecursive {


    public double calculateFutureValue(double currentValue, double growthRate, int years) {
      
        if (years == 0) {
            return currentValue;
        }
        
        return calculateFutureValue(currentValue * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        FinancialForecasting forecasting = new FinancialForecasting();
        double currentValue = 1000; 
        double growthRate = 0.05; 
        int years = 10; 

        double futureValue = forecasting.calculateFutureValue(currentValue, growthRate, years);
        System.out.println("Future Value: " + futureValue);
    }
}
