
package com.mycompany.taskmanagement;


public class TaskManagement {
    private TaskNode head;
    private TaskNode tail;

    public TaskManagement() {
        head = null;
        tail = null;
    }

   
    public void addTask(Task task) {
        TaskNode newNode = new TaskNode(task);
        if (tail == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
    }


    public Task searchTask(int taskId) {
        TaskNode current = head;
        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null; 
    }


    public void traverseTasks() {
        TaskNode current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

 
    public boolean deleteTask(int taskId) {
        TaskNode current = head;
        TaskNode previous = null;

        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                if (previous == null) {
                    head = current.next;
                } else {
                    previous.next = current.next;
                }
                if (current.next == null) {
                    tail = previous;
                }
                return true; 
            }
            previous = current;
            current = current.next;
        }
        return false; 
    }
}