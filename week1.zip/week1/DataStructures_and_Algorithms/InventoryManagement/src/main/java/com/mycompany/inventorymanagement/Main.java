package com.mycompany.inventorymanagement;

import com.mycompany.inventorymanagement.Product;
import java.util.HashMap;

public class Main {
    private HashMap<String, Product> inventory;

    public Main() {
        this.inventory = new HashMap<>();
    }

   
    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }

    
    public void updateProduct(String productId, int quantity, double price) {
        Product product = inventory.get(productId);
        if (product != null) {
            product.setQuantity(quantity);
            product.setPrice(price);
        }
    }

    
    public void deleteProduct(String productId) {
        inventory.remove(productId);
    }


    public Product getProduct(String productId) {
        return inventory.get(productId);
    }

    public void printAllProducts() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        Main manager = new Main();


        manager.addProduct(new Product("P001", "Laptop", 10, 999.99));
        manager.addProduct(new Product("P002", "Smartphone", 20, 499.99));

       
        manager.updateProduct("P001", 8, 899.99);

     
        manager.deleteProduct("P002");


        manager.printAllProducts();
    }
}
