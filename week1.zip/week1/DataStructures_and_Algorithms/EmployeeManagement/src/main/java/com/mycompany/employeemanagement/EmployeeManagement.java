
package com.mycompany.employeemanagement;


public class EmployeeManagement {
    private Employee[] employees;
    private int size;
    private static final int INITIAL_CAPACITY = 10;

    public EmployeeManagement() {
        employees = new Employee[INITIAL_CAPACITY];
        size = 0;
    }


    public void addEmployee(Employee employee) {
        if (size == employees.length) {
       
            Employee[] newArray = new Employee[employees.length * 2];
            System.arraycopy(employees, 0, newArray, 0, employees.length);
            employees = newArray;
        }
        employees[size++] = employee;
    }

    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null; 
    }


    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

   
    public boolean deleteEmployee(int employeeId) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            return false; 
        }
     
        System.arraycopy(employees, index + 1, employees, index, size - index - 1);
        employees[--size] = null;
        return true;
    }
}
