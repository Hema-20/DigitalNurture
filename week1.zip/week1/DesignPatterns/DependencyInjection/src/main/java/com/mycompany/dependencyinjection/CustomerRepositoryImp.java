
package com.mycompany.dependencyinjection;

public class CustomerRepositoryImp implements CustomerRepository {

    @Override
    public String findCustomerById(int id) {
       
        return "Customer with ID: " + id;
    }
}

