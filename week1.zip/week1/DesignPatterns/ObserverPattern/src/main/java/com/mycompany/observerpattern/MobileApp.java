
package com.mycompany.observerpattern;

public class MobileApp implements Observer {

    @Override
    public void update(double stockPrice) {
        System.out.println("MobileApp: Stock price updated to $" + stockPrice);
    }
}
