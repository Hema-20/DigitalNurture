
package com.mycompany.observerpattern;

public interface Observer {
    void update(double stockPrice);
}

