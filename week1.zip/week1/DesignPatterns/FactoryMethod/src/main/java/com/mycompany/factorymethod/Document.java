    
package com.mycompany.factorymethod;

public interface Document {
    void open();
    void close();
}
