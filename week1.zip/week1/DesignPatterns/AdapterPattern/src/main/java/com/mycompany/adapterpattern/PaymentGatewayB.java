
package com.mycompany.adapterpattern;

public class PaymentGatewayB {
    public void executePayment(double amount) {
        System.out.println("PaymentGatewayB processing payment of $" + amount);
    }
}

