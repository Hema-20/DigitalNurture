
package com.mycompany.adapterpattern;
public interface PaymentProcessor {
    void processPayment(double amount);
}

