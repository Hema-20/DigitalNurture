
package com.mycompany.adapterpattern;


public class PaymentGatewayA {
    public void makePayment(double amount) {
        System.out.println("PaymentGatewayA processing payment of $" + amount);
    }
}


