
package com.mycompany.commandpattern;

public interface Command {
    void execute();
}

