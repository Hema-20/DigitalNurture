    
package com.mycompany.decoratorpattern;

public interface Notifier {
    void send(String message);
}

