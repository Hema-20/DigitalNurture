
package com.mycompany.strategypattern;

public class StrategyPatternTest {

    public static void main(String[] args) {
   
        PaymentStrategy creditCard = new CreditCardPayment("1234-5678-9876-5432");
        PaymentStrategy payPal = new PayPalPayment("user@example.com");

        PaymentContext context = new PaymentContext(creditCard);
        context.executePayment(100.00);

        context = new PaymentContext(payPal);
        context.executePayment(200.00);
    }
}
