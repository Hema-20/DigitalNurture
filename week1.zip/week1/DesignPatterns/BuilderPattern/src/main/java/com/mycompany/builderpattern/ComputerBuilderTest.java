
package com.mycompany.builderpattern;

public class ComputerBuilderTest {

    public static void main(String[] args) {
       
        Computer basicComputer = new Computer.Builder("Intel i5", "8GB")
                .build();
        System.out.println(basicComputer);

 
        Computer gamingComputer = new Computer.Builder("Intel i7", "16GB")
                .setStorage("1TB SSD")
                .setGPU("NVIDIA GTX 3080")
                .setBluetoothEnabled(true)
                .build();
        System.out.println(gamingComputer);
    }
}

