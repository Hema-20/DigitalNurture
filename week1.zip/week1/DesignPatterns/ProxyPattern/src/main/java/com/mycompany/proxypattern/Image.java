
package com.mycompany.proxypattern;

public interface Image {
    void display();
}
